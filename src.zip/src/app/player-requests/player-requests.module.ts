import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PlayerRequestsPageRoutingModule } from './player-requests-routing.module';
import { PlayerRequestsPage } from './player-requests.page';
import { SharedModule } from "../shared/shared.module";
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SharedModule,
    PlayerRequestsPageRoutingModule
  ],
  declarations: [PlayerRequestsPage],
  entryComponents:[ ]
})
export class PlayerRequestsPageModule {}
