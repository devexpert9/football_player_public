var MAIN_URL = 'http://13.58.192.202:3002/';

export const config = {
  	API_URL : MAIN_URL,
	ENC_SALT: 'gd58_N9!ysS',
  	IMAGES_URL: MAIN_URL+'/uploads',
  	IMAGE_EXTENSIONS: ['image/png','image/jpg','image/jpeg','image/gif','image/bmp','image/webp']
};

export const social_config = {
  	FACEBOOK_ID: ''
};

